import React from 'react';
import Header from './components/Header';
import AnimeCard from './components/AnimeCard';
import { Tv, Zap, Users, Star } from 'lucide-react';

function App() {
  const trendingAnime = [
    {
      title: "Demon Slayer",
      image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800",
      rating: "9.5/10",
      episodes: 26
    },
    {
      title: "Attack on Titan",
      image: "https://images.unsplash.com/photo-1541562232579-512a21360020?auto=format&fit=crop&w=800",
      rating: "9.8/10",
      episodes: 87
    },
    {
      title: "One Punch Man",
      image: "https://images.unsplash.com/photo-1560972550-aba3456b5564?auto=format&fit=crop&w=800",
      rating: "9.3/10",
      episodes: 24
    },
    {
      title: "My Hero Academia",
      image: "https://images.unsplash.com/photo-1612487528505-d2338264c821?auto=format&fit=crop&w=800",
      rating: "9.4/10",
      episodes: 113
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      
      {/* Hero Section */}
      <section className="relative h-screen">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?auto=format&fit=crop&w=1920"
            alt="Hero Background"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 to-black/50" />
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
              Welcome to AnimeVerse
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Stream your favorite anime series and movies in high quality, anytime, anywhere.
              Whether you're into action, romance, fantasy, or slice-of-life, we've got something
              for every otaku.
            </p>
            <button className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-md text-lg font-semibold">
              Start Watching
            </button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-black/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-purple-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Tv className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-white text-xl font-semibold mb-2">Huge Collection</h3>
              <p className="text-gray-400">Access thousands of anime titles</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-white text-xl font-semibold mb-2">HD Streaming</h3>
              <p className="text-gray-400">Watch in stunning quality</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-white text-xl font-semibold mb-2">Community</h3>
              <p className="text-gray-400">Join discussions with other fans</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-white text-xl font-semibold mb-2">New Releases</h3>
              <p className="text-gray-400">Latest episodes and series</p>
            </div>
          </div>
        </div>
      </section>

      {/* Trending Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-8">Trending Now</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {trendingAnime.map((anime, index) => (
              <AnimeCard key={index} {...anime} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;