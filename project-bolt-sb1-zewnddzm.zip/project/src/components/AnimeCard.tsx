import React from 'react';
import { Play } from 'lucide-react';

interface AnimeCardProps {
  title: string;
  image: string;
  rating: string;
  episodes: number;
}

export default function AnimeCard({ title, image, rating, episodes }: AnimeCardProps) {
  return (
    <div className="group relative overflow-hidden rounded-lg">
      <img
        src={image}
        alt={title}
        className="w-full h-64 object-cover transform transition-transform group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="absolute bottom-0 p-4 w-full">
          <h3 className="text-white font-semibold text-lg">{title}</h3>
          <div className="flex items-center space-x-2 mt-2">
            <span className="text-yellow-400 text-sm">{rating}</span>
            <span className="text-gray-300 text-sm">•</span>
            <span className="text-gray-300 text-sm">{episodes} Episodes</span>
          </div>
          <button className="mt-3 flex items-center space-x-2 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-md">
            <Play className="w-4 h-4" />
            <span>Watch Now</span>
          </button>
        </div>
      </div>
    </div>
  );
}