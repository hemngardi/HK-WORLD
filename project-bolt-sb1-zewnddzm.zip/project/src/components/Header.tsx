import React from 'react';
import { Play, Search, Menu } from 'lucide-react';

export default function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Play className="w-8 h-8 text-purple-500" />
            <span className="ml-2 text-xl font-bold text-white">AnimeVerse</span>
          </div>
          
          <div className="hidden md:block">
            <div className="flex items-center space-x-4">
              <a href="#" className="text-gray-300 hover:text-white px-3 py-2">Home</a>
              <a href="#" className="text-gray-300 hover:text-white px-3 py-2">Browse</a>
              <a href="#" className="text-gray-300 hover:text-white px-3 py-2">New Releases</a>
              <a href="#" className="text-gray-300 hover:text-white px-3 py-2">My List</a>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <button className="text-gray-300 hover:text-white">
              <Search className="w-5 h-5" />
            </button>
            <button className="md:hidden text-gray-300 hover:text-white">
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}